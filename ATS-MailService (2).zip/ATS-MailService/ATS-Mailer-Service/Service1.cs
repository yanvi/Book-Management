﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using ATS_MailService;
using BCILLogger;
using System.IO;

namespace ATS_Mailer_Service
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }
         Logger logFile = new Logger();


        MailService service = default(MailService);

        protected override void OnStart(string[] args)
        {
            try
            {
                int PortNo = 80;
                var HostName = "host";//ConfigurationManager.AppSettings["HostName"];
                var Port = string.Empty;//ConfigurationManager.AppSettings["Port"];
                var SenderEmail = "dunny@dunny.com"; //ConfigurationManager.AppSettings["SenderEmail"];
                var UserId = "host"; //ConfigurationManager.AppSettings["UserId"];
                var SenderPassword = "host"; //ConfigurationManager.AppSettings["SenderPassword"];

                logFile.AppPath = ConfigurationManager.AppSettings["LogFilePath"];
                logFile.EnableLogging = true;
                logFile.ErrorFileName = "LOCAL";
                logFile.FileType = "DEBUG";
                logFile.MaxFileSize = 5;
                logFile.NoOfDaysToDeleteFile = 2;


               // bool validate = true;
                //if (string.IsNullOrEmpty(HostName))
                //{
                //    validate = false;
                //    logFile.WriteLog("Host Name is Blank !!! ");
                //}
                //if (!int.TryParse(Port, out PortNo))
                //{
                //    validate = false;
                //    logFile.WriteLog("Invalid Port Number !!! ");
                //}
                //if (string.IsNullOrEmpty(SenderEmail))
                //{
                //    validate = false;
                //    logFile.WriteLog("Sender Email is Blank !!! ");
                //}
                //if (string.IsNullOrEmpty(UserId))
                //{
                //    validate = false;
                //    logFile.WriteLog("Sender UserId is Blank !!! ");
                //}
                //if (string.IsNullOrEmpty(SenderPassword))
                //{
                //    validate = false;
                //    logFile.WriteLog("Sender Password is Blank !!! ");
                //}

                //if (validate == false)
                //{
                //    return;
                //}
                service = new MailService(HostName, PortNo, SenderEmail, UserId,SenderPassword);
                //service.logWrite.AppPath = ConfigurationManager.AppSettings["LogFilePath"];
                //service.logWrite.EnableLogging = true;
                //service.logWrite.ErrorFileName = "LOCAL";
                //service.logWrite.FileType = "DEBUG";
                //service.logWrite.MaxFileSize = 10;
                //service.logWrite.NoOfDaysToDeleteFile = 5;
                service.OnSendedMail += service_OnSendedMail;
                service.StartService();
                logFile.WriteLog("Serive Strated At:" + DateTime.Now);
            }

            catch (Exception ex)
            {
                logFile.WriteLog(ex);
            }

        }

        protected override void OnStop()
        {
            try
            {
                if (service != null)
                {
                    service.StopService();
                    logFile.WriteLog("Serive stopped at:" + DateTime.Now);
                }
                else
                {
                    logFile.WriteLog("Service object is not initilized  while stopping service :" + DateTime.Now);
                }
            }
            catch (Exception ex)
            {
                logFile.WriteLog("Error ocured while stoping service" + DateTime.Now + "\n");
                logFile.WriteLog(ex);
            }
        }

        private void service_OnSendedMail(string message)
        {
            //try
            //{
            //    logFile.WriteLog(message);
            //    System.Threading.Thread.Sleep(50);
            //}
            //catch (Exception ex)
            //{
            //    logFile.WriteLog(ex);
            //}
        }
    }
}
