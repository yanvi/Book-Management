﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Net;

namespace ATS_MailService
{
  
    
/// <summary>
/// Summary description for ATSMail
/// </summary>
   
    
public class ATSMail
{
    private readonly string DisplayName = "RTS  Mail Service";
    private MailMessage _atsMail = null;
    private SmtpClient _atsMailClient = null;
    private MailAddress _fromAddress = null;

    public readonly string HostName;
    public readonly int Port;
    public readonly string From;
    public readonly string UserId;
    public readonly string SenderPassword;

    public string Recipients { get; set; }
    public string Subject { get; set; }
    public string MailContent { get; set; }
    public bool IsBodyHtml { get; set; }
    public string CCRecipients { get; set; }
   
 
    public ATSMail(string hostName, int port, string from ,string UserId,string SenderPassword)
    {
        this.HostName = hostName;
        this.Port = port;
        this.From = from;
        this.UserId = UserId;
        this.SenderPassword = SenderPassword;
        _atsMail = new MailMessage();

        _atsMailClient = new SmtpClient();
        _fromAddress = new MailAddress(this.From, this.DisplayName);
        _atsMail.From = _fromAddress;
        _atsMailClient.Host = this.HostName;
        _atsMailClient.Port = this.Port;
     
        _atsMailClient.UseDefaultCredentials = false;
        _atsMailClient.EnableSsl = true;
       // _atsMailClient.UseDefaultCredentials = true;
       
        _atsMailClient.Credentials = new NetworkCredential(this.UserId, this.SenderPassword);

      
        
    }
    public bool Send(string Recipients, string Subject, bool IsMailHtmlBody, string MailBody)
    {
        try
        {
            this.Recipients = Recipients;
            this.Subject = Subject;
            this.IsBodyHtml = IsBodyHtml;
            this.MailContent = MailBody;
            _atsMail.Body = this.MailContent;
            bool result = this.SendMail();
            return result;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool Send()
    {
        try
        {
            bool result = this.SendMail();
            return result;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private bool SendMail()
    {
        try
        {
           
            _atsMail.To.Add(this.Recipients);
            _atsMail.Subject = this.Subject;
            _atsMail.IsBodyHtml = this.IsBodyHtml;
            _atsMail.Body = this.MailContent;

            this._atsMailClient.Send(this._atsMail);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
}
