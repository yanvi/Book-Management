﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ATS_MailService
{
    public class AlertDisableCategory
    {
        public string CategoryName { get; set; }
        public bool IsDisable { get; set; }
        public AlertDisableCategory()
        {
            this.CategoryName = string.Empty;
            this.IsDisable = default(bool);
        }
    }

   



}
