﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace DataAccess
{

    public sealed class DlCommon
    {
        private DBManager _dbManager = null;
        public DlCommon()
        {
            try
            {
                _dbManager = new DBManager(DataProvider.SqlServer, Convert.ToString(ConfigurationSettings.AppSettings["Constr"]));
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public DBManager DBProvider
        {
            get
            {
                return _dbManager;
            }

        }
    }
}



